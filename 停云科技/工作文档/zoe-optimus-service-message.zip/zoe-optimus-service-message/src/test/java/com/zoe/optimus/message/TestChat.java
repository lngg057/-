package com.zoe.optimus.message;

import java.io.IOException;
import java.util.List;

import org.jivesoftware.smack.ConnectionConfiguration.SecurityMode;
import org.jivesoftware.smack.SmackException;
import org.jivesoftware.smack.SmackException.NoResponseException;
import org.jivesoftware.smack.SmackException.NotConnectedException;
import org.jivesoftware.smack.XMPPException;
import org.jivesoftware.smack.XMPPException.XMPPErrorException;
import org.jivesoftware.smack.chat.Chat;
import org.jivesoftware.smack.chat.ChatManager;
import org.jivesoftware.smack.chat.ChatManagerListener;
import org.jivesoftware.smack.chat.ChatMessageListener;
import org.jivesoftware.smack.packet.Message;
import org.jivesoftware.smack.packet.Presence;
import org.jivesoftware.smack.packet.Message.Type;
import org.jivesoftware.smack.tcp.XMPPTCPConnection;
import org.jivesoftware.smack.tcp.XMPPTCPConnectionConfiguration;
import org.jivesoftware.smackx.offline.OfflineMessageManager;

import com.zoe.optimus.service.message.util.SmackUtil;

/**
 * <p>标题：</p>
 * <p>描述：</p>
 * <p>版权：Copyright (c) 2016</p>
 * <p>公司：智业股份有限公司</p>
 *
 * @version 1.0
 * @author wjx
 * @createDate 2016年11月22日
 */
public class TestChat {
	
	public static void main(String[] args) throws Exception {
		XMPPTCPConnection connection = SmackUtil.getInstanceFor("admin", "admin");
		Message packet = new Message();
		packet.setTo("admin@broadcast.com.zoe.optimus");
		packet.setBody("ggg");
		packet.setType(Type.chat);
		connection.sendStanza(packet);
	}
	
	
	
	public static XMPPTCPConnection login(String uid,String pwd) throws XMPPException, SmackException, IOException{
		XMPPTCPConnectionConfiguration conf = XMPPTCPConnectionConfiguration.builder()
			      .setServiceName("yy-jianxiongwu").setUsernameAndPassword(uid, pwd)
			      .setSecurityMode(SecurityMode.disabled)
			      .setSendPresence(false)
			      .setCompressionEnabled(false).build();
		XMPPTCPConnection connection = new XMPPTCPConnection(conf);
		connection.connect();
		connection.login();
		return connection;
	}
	
	public static void test1() throws XMPPException, SmackException, IOException{
		XMPPTCPConnection connection = login("n100", "123456");
		OfflineMessageManager offlineMessageManager = new OfflineMessageManager(connection);
		List<Message> offMsgs = offlineMessageManager.getMessages();
		for (Message message : offMsgs) {
			System.out.println("offlineMessage:"+message.toXML());
		}
		offlineMessageManager.deleteMessages();
		Presence presence = new Presence(Presence.Type.available);
		connection.sendStanza(presence);//上线了
		
		//接收消息
		ChatManager chatManager = ChatManager.getInstanceFor(connection);
		chatManager.addChatListener(new ChatManagerListener() {
		
			@Override
			public void chatCreated(Chat chat, boolean createdLocally) {
				  chat.addMessageListener(new ChatMessageListener() {
					  @Override
					  public void processMessage(Chat chat, Message message) {
						  System.out.println("onlineMessage:"+message.toXML());
					  }
				  });
			}
		});
		while(true);
	}
}
