package com.zoe.optimus.message;

import org.jivesoftware.smack.packet.DefaultExtensionElement;
import org.jivesoftware.smack.tcp.XMPPTCPConnection;
import org.jivesoftware.smackx.pubsub.ItemPublishEvent;
import org.jivesoftware.smackx.pubsub.Node;
import org.jivesoftware.smackx.pubsub.PayloadItem;
import org.jivesoftware.smackx.pubsub.PubSubManager;
import org.jivesoftware.smackx.pubsub.listener.ItemEventListener;

import com.zoe.optimus.service.message.util.SmackUtil;

import net.sf.ehcache.config.generator.model.NodeElement;

/**
 * <p>标题：</p>
 * <p>描述：</p>
 * <p>版权：Copyright (c) 2016</p>
 * <p>公司：智业股份有限公司</p>
 *
 * @version 1.0
 * @author wjx
 * @createDate 2016年11月22日
 */
public class Receiver {

	/**
	 * @author wjx
	 * @date 2016年11月22日
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception {
		XMPPTCPConnection connection = SmackUtil.getInstanceFor("n100", "123456");
		PubSubManager manager = new PubSubManager(connection);  
        Node eventNode = manager.getNode("betalot_test");  
        eventNode.addItemEventListener(new ItemEventListener<PayloadItem>() {  
            public void handlePublishedItems(ItemPublishEvent<PayloadItem> evt) {  
                for (Object obj : evt.getItems()) {  
                    PayloadItem item = (PayloadItem) obj;  
                    System.out.println("--:Payload=" + item.getElementName());  
                    
                }  
            }  
        });  
        eventNode.subscribe(connection.getUser());  
        while(true);  
	}

}
