package com.zoe.optimus.message;

import org.jivesoftware.smack.packet.DefaultExtensionElement;
import org.jivesoftware.smack.tcp.XMPPTCPConnection;
import org.jivesoftware.smackx.pubsub.LeafNode;
import org.jivesoftware.smackx.pubsub.PayloadItem;
import org.jivesoftware.smackx.pubsub.PubSubManager;
import org.jivesoftware.smackx.pubsub.SimplePayload;

import com.zoe.optimus.service.message.util.SmackUtil;

/**
 * <p>标题：</p>
 * <p>描述：</p>
 * <p>版权：Copyright (c) 2016</p>
 * <p>公司：智业股份有限公司</p>
 *
 * @version 1.0
 * @author wjx
 * @createDate 2016年11月22日
 */
public class Publisher {

	/**
	 * @author wjx
	 * @date 2016年11月22日
	 * @param args
	 */
	public static void main(String[] args) {
		try{  
			XMPPTCPConnection connection = SmackUtil.getInstanceFor("n101", "123456");
            PubSubManager manager = new PubSubManager(connection);  
            String nodeId = "betalot_test";  
              
            LeafNode myNode = null;  
            try {  
                myNode = manager.getNode(nodeId);  
            } catch (Exception e) {  
                e.printStackTrace();  
            }  
            if(myNode == null){  
                myNode = manager.createNode(nodeId);  
            }  
              
            String msg = "hello world as---";  
              
//            SimplePayload payload = new SimplePayload("message","pubsub:test:message", "<message xmlns='pubsub:test:message'><body>"+msg+"</body></message>");  
            DefaultExtensionElement element = new DefaultExtensionElement("message", "pubsub:test:message");
            element.setValue("body", msg);
            PayloadItem<DefaultExtensionElement> item = new PayloadItem<DefaultExtensionElement>("5", element);  
  
            myNode.publish(item);  
            System.out.println("-----publish-----------");  
        }  catch(Exception e) {
        	e.printStackTrace();
    	} 
	}

}
