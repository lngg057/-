package com.zoe.optimus.service.message.service;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

import org.jivesoftware.smack.packet.DefaultExtensionElement;
import org.jivesoftware.smack.packet.Message;
import org.jivesoftware.smack.tcp.XMPPTCPConnection;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.zoe.optimus.service.message.entity.MessagePacket;
import com.zoe.optimus.service.message.util.DateUtils;
import com.zoe.optimus.service.message.util.SmackUtil;
import com.zoe.optimus.service.message.util.ValidUtil;

/**
 * 消息发送
 * <p>
 * 标题：
 * </p>
 * <p>
 * 描述：
 * </p>
 * <p>
 * 版权：Copyright (c) 2016
 * </p>
 * <p>
 * 公司：智业股份有限公司
 * </p>
 *
 * @version 1.0
 * @author wjx
 * @createDate 2016年11月17日
 */
@Service
public class SendService {

	public SendService() {
		super();
	}

	public static void sendMessage(String message, String userCode, String password) throws Exception {
		XMPPTCPConnection connection = SmackUtil.getInstanceFor(userCode, password);
//		Presence presence = new Presence(Presence.Type.available);
//		connection.sendStanza(presence);//上线了
		handleMessage(message, connection);
//		SmackUtil.disconnect(connection);
	}

	/**
	 * @author wjx
	 * @date 2016年11月16日
	 */
	public void exit(XMPPTCPConnection connection) {
		SmackUtil.disconnect(connection);
	}

	/**
	 * 解析前端发送的消息，并推送到xmpp服务器
	 *
	 * @param p
	 *            消息包
	 * @param connection
	 *            和服务器的连接
	 */
	public static void handleMessage(String msg, XMPPTCPConnection connection) throws Exception {

		MessagePacket p = JSON.parseObject(msg, MessagePacket.class);
		String toSuffix = resolveType(p.getType());
		for (String user : resolveUsers(p.getUsers())) {
			Message message = new Message();
			String to = user + toSuffix;
			message.setTo(to);
			message.setBody(p.getBody());
			message.setType(Message.Type.normal);
			DefaultExtensionElement extension = new DefaultExtensionElement("dict", null);
			extension.setValue("type", p.getType() == 1 ? "普通消息" : "广播消息");
			extension.setValue("subject", ValidUtil.isNotEmptyAndNull(p.getSubject()) ? p.getSubject():p.getBody().substring(0, p.getBody().length()>30?30:p.getBody().length()));
			extension.setValue("sendTime", DateUtils.getDateTime());
			message.addExtension(extension);
			connection.sendStanza(message);
		}
	}

	/**
	 * 解析接受者
	 *
	 * @param users
	 *            逗号分隔的用户串
	 * @return Set 用户Set集合，避免重复发送
	 */
	private static Set<String> resolveUsers(String users) {
		Set<String> result = new HashSet<>();
		if (users == null) {
			return result;
		}
		String[] split = users.split(",");
		Collections.addAll(result, split);
		return result;
	}

	/**
	 * 解析类型获得后缀
	 *
	 * @param type
	 *            类型参数
	 * @return String 服务后缀，默认为普通的
	 */
	private static String resolveType(int type) {
		switch (type) {
		case MessagePacket.BROADCAST:
			return SmackUtil.BROADCAST_SUFFIX;
		case MessagePacket.NORMAL:
		default:
			return SmackUtil.NORMAL_SUFFIX;
		}
	}

}