package com.zoe.optimus.service.message.entity;

@SuppressWarnings("serial")
public class MessagePacket extends BaseEntity{
  /**
   * 普通消息
   */
  public static final int NORMAL = 1;
  /**
   * 广播消息
   */
  public static final int BROADCAST = 2;
  /**
   * 消息类型
   */
  private int type;
  /**
   * 消息主题
   */
  private String subject;
  /**
   * 消息内容
   */
  private String body;
  /**
   * 接受者，多个接受者用英文逗号分隔
   */
  private String users;
  
  

  public MessagePacket() {
	  super();
  }
	
	public int getType() {
	    return type;
	  }
	
	  public void setType(int type) {
	    this.type = type;
	  }
	
	  public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getBody() {
	    return body;
	  }
	
	  public void setBody(String body) {
	    this.body = body;
	  }
	
	  public String getUsers() {
	    return users;
	  }
	
	  public void setUsers(String users) {
	    this.users = users;
	  }

}
