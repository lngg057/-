package com.zoe.optimus.service.message.util;

import java.util.UUID;

/**
 * <p>标题: ID生成工具类</p>
 * <p>描述: </p>
 * <p>版权: Copyright (c) 2016</p>
 * <p>公司: </p>
 *
 * @version: 1.0
 * @author: ffs
 */
public class IdUtils {
	/**
	 * 生成UUID
	 * @param withLinkLine 是否带横线
	 * @return uuid字符串
	 */
	public static String uuid(boolean withLinkLine) {
		String uuidStr = UUID.randomUUID().toString();
		if (withLinkLine) {
			return uuidStr;
		}
		return uuidStr.replaceAll("-", "");
	}

	/**
	 * 生成带横线的UUID
	 * @return uuid字符串
	 */
	public static String uuid() {
		return uuid(true);
	}
}
