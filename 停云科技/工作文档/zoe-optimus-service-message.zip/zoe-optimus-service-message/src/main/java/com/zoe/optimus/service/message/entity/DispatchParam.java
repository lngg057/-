package com.zoe.optimus.service.message.entity;

/**
 * <p>
 * 标题：服务分发参数
 * </p>
 * <p>
 * 描述：
 * </p>
 * <p>
 * 版权：Copyright (c) 2016
 * </p>
 * <p>
 * 公司：智业股份有限公司
 * </p>
 *
 * @version 1.0
 * @author wjx
 * @createDate 2016年11月18日
 */
public class DispatchParam {

	/**
	 * 认证用户名
	 */
	private String userCode;
	/**
	 * 认证密码
	 */
	private String password;
	/**
	 * 消息体
	 */
	private String messageBody;

	public DispatchParam() {
		super();
	}
	
	

	public DispatchParam(String userCode, String password, String messageBody) {
		super();
		this.userCode = userCode;
		this.password = password;
		this.messageBody = messageBody;
	}



	public String getUserCode() {
		return userCode;
	}

	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getMessageBody() {
		return messageBody;
	}

	public void setMessageBody(String messageBody) {
		this.messageBody = messageBody;
	}

}
