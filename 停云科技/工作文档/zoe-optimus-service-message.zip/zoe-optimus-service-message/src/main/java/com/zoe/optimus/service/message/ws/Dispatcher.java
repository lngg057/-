package com.zoe.optimus.service.message.ws;

import java.lang.reflect.Field;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;

import com.alibaba.fastjson.JSON;
import com.zoe.optimus.service.message.entity.DispatchParam;
import com.zoe.optimus.service.message.service.SendService;
import com.zoe.optimus.service.message.util.SmackUtil;

/**
 * <p>标题：接口统一入口</p>
 * <p>描述：</p>
 * <p>版权：Copyright (c) 2016</p>
 * <p>公司：智业股份有限公司</p>
 *
 * @version 1.0
 * @author wjx
 * @createDate 2016年11月18日
 */
@WebService
public class Dispatcher {
	
	private static final String ERROR_PARAM = "接口参数错误，请检查！";
	private static final String ERROR_AUTH = "用户认证失败！";

	/**
	 * json入参调用服务
	 * @author wjx
	 * @date 2016年11月18日
	 * @param dispatchParam 
	 * {userCode:"XXX",password:"***",messageBody:"{type:\"1\",users:\"test\",body:\"这是一个测试消息发送接口的通知\",subject:\"消息发送接口测试\"}"}
	 * @return
	 */
	@WebMethod
	public String doDispatchJson(@WebParam(name="dispatchParam") String dispatchParam){
		DispatchParam param = JSON.parseObject(dispatchParam, DispatchParam.class);
		if (!checkParam(param)) {
			return ERROR_PARAM;
		}
		boolean isAuth = SmackUtil.authentication(param.getUserCode(), param.getPassword());
		if (!isAuth)
			return ERROR_AUTH;
		String response = "success";
		try {
			SendService.sendMessage(param.getMessageBody(),param.getUserCode(), param.getPassword());
		}catch (Exception e) {
			response = e.getMessage();
		}
		return response;
		
	}
	
	private boolean checkParam(DispatchParam param){
		
		Field[] fields = param.getClass().getDeclaredFields();
		for (Field field : fields) {
			try {
				if (field.get(param)==null) {
					return false;
				}
			} catch (IllegalArgumentException | IllegalAccessException e) {
				return false;
			}
		}
		return true;
		
	}
}
