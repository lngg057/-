package com.zoe.optimus.service.message.entity;

import java.io.Serializable;

/**
 * <p>标题: 实体基类</p>
 * <p>描述: </p>
 * <p>版权: Copyright (c) 2016</p>
 * <p>公司: </p>
 *
 * @version: 1.0
 * @author: wjx
 */
@SuppressWarnings("serial")
public class BaseEntity implements Serializable {
}
