package com.zoe.optimus.service.message.web;

import java.io.IOException;
import java.util.concurrent.CopyOnWriteArraySet;

import javax.websocket.OnClose;
import javax.websocket.OnError;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.Session;
import javax.websocket.server.PathParam;
import javax.websocket.server.ServerEndpoint;

import com.zoe.optimus.service.message.service.InternalMessageService;
import com.zoe.optimus.service.message.service.ReceiveBroker;

/**
 * <p>标题：</p>
 * <p>描述：</p>
 * <p>版权：Copyright (c) 2016</p>
 * <p>公司：智业股份有限公司</p>
 *
 * @version 1.0
 * @author wjx
 * @createDate 2016年11月7日
 */
//该注解用来指定一个URI，客户端可以通过这个URI来连接到WebSocket。类似Servlet的注解mapping。无需在web.xml中配置。
@ServerEndpoint("/message/{userCode}/{password}")
public class MessageSocket {
	
    //与某个客户端的连接会话，需要通过它来给客户端发送数据
    private Session session;
    //连接的用户
    private String userCode;
    
    ReceiveBroker broker;
    
    private static CopyOnWriteArraySet<MessageSocket> sessions = new CopyOnWriteArraySet<MessageSocket>();
    
    private static InternalMessageService service;
    
    static {
        service = new InternalMessageService();
    }
    
     
    /**
     * 连接建立成功调用的方法
     * @param session  可选的参数。session为与某个客户端的连接会话，需要通过它来给客户端发送数据
     * @throws Exception 
     */
    @OnOpen
    public void onOpen(@PathParam("userCode") String userCode,@PathParam("password") String password,Session session) throws Exception{
		this.session = session;
		this.userCode = userCode;
		sessions.add(this);
		broker = new ReceiveBroker(this.userCode, password,this.session);
		service.connect(broker);
    }
     
    /**
     * 连接关闭调用的方法
     * @throws IOException 
     */
    @OnClose
    public void onClose() throws IOException{
    	int clientCount = 0;
    	for (MessageSocket messageSocket : sessions) {
    		if (clientCount>1) {
				break;
			}
			if (userCode.equals(messageSocket.getUserCode())) {
				++clientCount;
			}
		}
    	boolean isOtherConnect = true;
    	if (clientCount == 1) {
    		isOtherConnect = false;
		}
    	broker.exit(isOtherConnect);
    	sessions.remove(this);
    }
     
    /**
     * 收到客户端消息后调用的方法
     * @param message 客户端发送过来的消息
     * @param session 可选的参数
     */
    @OnMessage
    public void onMessage(String message) {
    }
     
    /**
     * 发生错误时调用
     * @param session
     * @param error
     */
    @OnError
    public void onError(Session session, Throwable error){
        System.out.println("发生错误");
        error.printStackTrace();
    }
    
    /**
     * 给用户userCode发送消息
     * @author wjx
     * @date 2016年11月25日
     * @param userCode
     * @param message
     */
    public static void sendUserMessage(String userCode,String message){
    	
    	for (MessageSocket messageSocket : sessions) {
    		try {
    			if (userCode.equals(messageSocket.getUserCode())) {
    				messageSocket.sendMessage(message);
				}
			} catch (IOException e) {
				e.printStackTrace();
				continue;
			}
		}
    }
     
    /**
     * 这个方法与上面几个方法不一样。没有用注解，是根据自己需要添加的方法。
     * @param message
     * @throws IOException
     */
    public void sendMessage(String message) throws IOException{
        this.session.getBasicRemote().sendText(message);
        //this.session.getAsyncRemote().sendText(message);
    }

	public String getUserCode() {
		return userCode;
	}

 
}
