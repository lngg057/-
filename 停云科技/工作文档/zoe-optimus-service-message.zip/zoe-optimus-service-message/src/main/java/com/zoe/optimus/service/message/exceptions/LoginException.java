package com.zoe.optimus.service.message.exceptions;

/**
 * <p>标题：</p>
 * <p>描述：</p>
 * <p>版权：Copyright (c) 2016</p>
 * <p>公司：智业股份有限公司</p>
 *
 * @version 1.0
 * @author wjx
 * @createDate 2016年11月16日
 */
@SuppressWarnings("serial")
public class LoginException extends Exception{

	/**
	 * 构造函数
	 */
	public LoginException() {
		super("登录认证失败！");
	}

}
