package com.zoe.optimus.service.message.web;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSON;
import com.zoe.optimus.service.message.entity.DispatchParam;
import com.zoe.optimus.service.message.entity.ResultModel;
import com.zoe.optimus.service.message.service.InternalMessageService;
import com.zoe.optimus.service.message.service.SendService;

/**
 * <p>标题：事件触发控制器</p>
 * <p>描述：</p>
 * <p>版权：Copyright (c) 2016</p>
 * <p>公司：智业股份有限公司</p>
 *
 * @version 1.0
 * @author wjx
 * @createDate 2016年11月7日
 */
@Controller
@RequestMapping(value="/messageEvent")
public class MessageEventController{
	
	@Autowired
	private InternalMessageService service;
	/**
	 * 发送消息到xmpp服务器
	 * @author wjx
	 * @date 2016年11月18日
	 * @param request
	 * @param response
	 * @param parameter  
	 * {userCode:"XXX",password:"***",messageBody:"{type:\"1\",users:\"test\",body:\"这是一个测试消息发送接口的通知\",subject:\"消息发送接口测试\"}"}
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value="/sendMessage")
    public ResultModel  sendMessage(HttpServletRequest request,HttpServletResponse response,String parameter){
		DispatchParam param = JSON.parseObject(parameter, DispatchParam.class);
		try {
			SendService.sendMessage(param.getMessageBody(),param.getUserCode(), param.getPassword());
		} catch (Exception e) {
			return ResultModel.fail(ResultModel.ERROR_CODE, "", e.getMessage());
		}
		
		return ResultModel.success("发送消息成功", null);

    }
	/**
	 * 
	 * @author wjx
	 * @date 2016年11月18日
	 * @param request
	 * @param response
	 * @param parameter
	 * @return
	 */
	@SuppressWarnings("unchecked")
	@ResponseBody
	@RequestMapping(value="/readMessage")
	public ResultModel readMessage(HttpServletRequest request,HttpServletResponse response,String parameter){
		
		try {
			Map<String, Object> map = (Map<String, Object>) JSON.parse(parameter);
			service.readMessage(map);
		} catch (Exception e) {
			return ResultModel.fail(ResultModel.ERROR_CODE, "", e.getMessage());
		}
		return ResultModel.success("读取消息成功", null);
	}
	/**
	 * 
	 * @author wjx
	 * @date 2016年11月18日
	 * @param request
	 * @param response
	 * @param parameter
	 * @return
	 */
	@SuppressWarnings("unchecked")
	@ResponseBody
	@RequestMapping(value="/clearMessages")
	public ResultModel clearMessages(HttpServletRequest request,HttpServletResponse response,String parameter){
		
		try {
			Map<String, Object> map = (Map<String, Object>) JSON.parse(parameter);
			String messageIDs = map.get("messageIds")+"";
			map.put("messageIds", messageIDs.split(","));
			service.readMessage(map);
		} catch (Exception e) {
			return ResultModel.fail(ResultModel.ERROR_CODE, "", e.getMessage());
		}
		return ResultModel.success("读取消息成功", null);
	}
}
