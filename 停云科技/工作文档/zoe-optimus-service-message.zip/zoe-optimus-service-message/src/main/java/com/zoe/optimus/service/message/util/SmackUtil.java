package com.zoe.optimus.service.message.util;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.jivesoftware.smack.tcp.XMPPTCPConnection;
import org.jivesoftware.smack.tcp.XMPPTCPConnectionConfiguration;
import org.jivesoftware.smackx.iqregister.AccountManager;
import org.jivesoftware.smackx.search.ReportedData;
import org.jivesoftware.smackx.search.UserSearchManager;
import org.jivesoftware.smackx.xdata.Form;

import com.zoe.optimus.service.message.exceptions.ConnectionException;
import com.zoe.optimus.service.message.exceptions.LoginException;


/**
 * <p>标题：</p>
 * <p>描述：</p>
 * <p>版权：Copyright (c) 2016</p>
 * <p>公司：智业股份有限公司</p>
 *
 * @version 1.0
 * @author wjx
 * @createDate 2016年11月7日
 */
public class SmackUtil {
	
	private static PropertiesLoader loader = new PropertiesLoader("application.properties");
	private static final String SERVICE_NAME = loader.getProperty("openfire_service");//"com.zoe.optimus";
	private static final String HOST = loader.getProperty("openfire_host");//"127.0.0.1";
	private static final String PORT = loader.getProperty("openfire_port");//5222;
	public static final String BROADCAST_SUFFIX = "@broadcast." + SERVICE_NAME;
	public static final String NORMAL_SUFFIX = "@" + SERVICE_NAME;
	public static final String SEARCH_SERVICE = "search." + SERVICE_NAME;

    private static Map<String,XMPPTCPConnection> connInstances = new ConcurrentHashMap<String, XMPPTCPConnection>();
    
    /**
     * 获取连接实例
     * @author wjx
     * @date 2016年11月18日
     * @param user
     * @param password
     * @return
     * @throws Exception
     */
    public static synchronized XMPPTCPConnection getInstanceFor(String user, String password) throws Exception{
    	XMPPTCPConnection connection = connInstances.get(user);
    	if (connection == null) {
    		connection = loginOrRegister(user,password);
    	}
		return connection;
    }
    /**
     * 登录认证
     * @author wjx
     * @date 2016年11月18日
     * @param user
     * @param password
     * @return
     */
    public static boolean authentication(String user,String password){
    	XMPPTCPConnection connection = connInstances.get(user);
    	if (connection == null) {
    		try {
				connection = login(user,password);
			} catch (Exception e) {
				return false;
			}
    	}else{
    		disconnect(connection);
    		try {
				connection = login(user,password);
			} catch (Exception e) {
				return false;
			}
    	}
    	return true;
    }
    /**
     * 连接服务器
     * @return
     * @throws ConnectionException 
     */
    public static XMPPTCPConnection getConnection() throws ConnectionException {
    	try {
        	XMPPTCPConnectionConfiguration config = XMPPTCPConnectionConfiguration.builder()
        	.setHost(HOST)
        	.setPort(Integer.parseInt(PORT))
        	//服务器名称
        	.setServiceName(SERVICE_NAME)
        	//是否开启安全模式
        	.setSecurityMode(XMPPTCPConnectionConfiguration.SecurityMode.disabled)
        	//是否开启压缩
        	.setCompressionEnabled(false)
        	//是否告诉服务器上线状态
        	.setSendPresence(false)
        	//开启调试模式
        	.setDebuggerEnabled(true).build();
        	
        	XMPPTCPConnection connection = new XMPPTCPConnection(config);
            connection.connect();
            return connection;
        } catch (Exception e) {
        	throw new ConnectionException();
        }
    }

   /**
     * 登陆
     * @param user		用户账号
     * @param password		用户密码
     * @return
     * @throws Exception 
     */
    public static XMPPTCPConnection login(String user, String password) throws Exception {
        try {
        	XMPPTCPConnection connection = SmackUtil.getConnection();
        	connection.login(user, password);
        	connInstances.put(user, connection);
            return  connection;
        } catch (ConnectionException e) {
            throw e;
        } catch (Exception e) {
        	throw new LoginException();
		}
    }

    /**
     * 是否已经注册
     *
     * @param username 用户名
     */
    public static boolean isRegistered(String username) throws Exception {
    	XMPPTCPConnection connection = SmackUtil.getConnection();
    	connection.loginAnonymously();
        UserSearchManager searcher = new UserSearchManager(connection);
        Form searchForm = searcher.getSearchForm(SEARCH_SERVICE);
        Form answerForm = searchForm.createAnswerForm();
        answerForm.setAnswer("Username", true);
        answerForm.setAnswer("search", username);
        ReportedData reportedData = searcher.getSearchResults(answerForm, SEARCH_SERVICE);
        boolean isRegistered = !reportedData.getRows().isEmpty();
        connection.instantShutdown();
        return isRegistered;
    }


    /**
     * 注册
     * @author wjx
     * @date 2016年11月8日
     * @param username
     * @param password
     * @return
     */
    public static XMPPTCPConnection register(String username, String password)  throws Exception  {
    	XMPPTCPConnection conn = SmackUtil.getConnection();
	    try {
			AccountManager manager = AccountManager.getInstance(conn);
			manager.sensitiveOperationOverInsecureConnection(true);
			manager.createAccount(username, password);
			conn.login(username, password);
			connInstances.put(username, conn);
		} catch (Exception e) {
			throw new LoginException();
		}
        return conn;
        
    }

    
    /**
     * 直接登录或者新建用户后登录
     *
     * @param conn     XMPP连接
     * @param username 用户名
     * @param password 密码
     */
    public static XMPPTCPConnection loginOrRegister(String username, String password) throws Exception {
    	XMPPTCPConnection connection = null;
    	if (!isRegistered(username)) {
            connection = register(username, password);
        }else{
        	connection = login(username, password);
        }
		return connection;
    }
    /**
     * 关闭和xmpp服务器的连接
     *
     * @param connection 连接
     */
    public static void disconnect(XMPPTCPConnection connection) {
        if (connection != null && connection.isConnected()) {
        	if (connection.getUser() != null) {
        		connInstances.remove(connection.getUser().split("@")[0]);
        	}
            connection.disconnect();
        }
    }

   


    /**
     * 根据用户名获取用户的JID
     *
     * @param username 用户名
     * @return String 用户JID [username]@[service_name]
     */
    public static String getUser(String username) {
        return username + NORMAL_SUFFIX;
    }

    /**
     * 获取房间的JID
     *
     * @param roomName 房间名
     * @return String 房间JID [room_name]@[conference].[service_name]
     */
    public static String getRoom(String roomName) throws Exception {
        return roomName + "@conference." + SERVICE_NAME;
    }

    /**
     * 获取广播JID，
     *
     * @param group 组名，如果为空则设置为 all
     * @return String 广播JID [group]@[broadcast].[service_name]
     */
    public static String getBroadcast(String group) {
        if (group == null) {
            group = "all";
        }
        return group + BROADCAST_SUFFIX;
    }

}
