package com.zoe.optimus.service.message.service;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;

import javax.websocket.Session;

import org.jivesoftware.smack.chat.Chat;
import org.jivesoftware.smack.chat.ChatManager;
import org.jivesoftware.smack.chat.ChatManagerListener;
import org.jivesoftware.smack.chat.ChatMessageListener;
import org.jivesoftware.smack.packet.DefaultExtensionElement;
import org.jivesoftware.smack.packet.Message;
import org.jivesoftware.smack.packet.Presence;
import org.jivesoftware.smack.tcp.XMPPTCPConnection;
import org.jivesoftware.smackx.offline.OfflineMessageManager;

import com.alibaba.fastjson.JSON;
import com.zoe.optimus.service.message.dao.MessageDao;
import com.zoe.optimus.service.message.util.ClobUtil;
import com.zoe.optimus.service.message.util.IdUtils;
import com.zoe.optimus.service.message.util.SmackUtil;
import com.zoe.optimus.service.message.util.SpringContextHolder;
import com.zoe.optimus.service.message.web.MessageSocket;



/**
 * 消息接收代理
 * <p>标题：</p>
 * <p>描述：</p>
 * <p>版权：Copyright (c) 2016</p>
 * <p>公司：智业股份有限公司</p>
 *
 * @version 1.0
 * @author wjx
 * @createDate 2016年11月17日
 */
public class ReceiveBroker implements Runnable {

  private XMPPTCPConnection connection;
  private String userCode;
  private String password;
  private Session session;
  private static CopyOnWriteArraySet<ReceiveBroker> clients = new CopyOnWriteArraySet<ReceiveBroker>();

  
  private MessageDao messageDao = (MessageDao) SpringContextHolder.getBean("messageDao"); 

  public ReceiveBroker(String userCode,String password,Session session) {
    this.userCode = userCode;
    this.password = password;
    this.session =session;
    clients.add(this);
  }



@Override
  public void run() {
	  try {
		  connection = SmackUtil.getInstanceFor(userCode, password);
	      getUserPacket();
	  } catch (IOException e) {
		  e.printStackTrace();
	  } catch (Exception e) {
	      e.printStackTrace();
	  }
  }
  
  private void getUserPacket() throws Exception{
	  //获取未读的消息
	  Map<String, Object> params = new HashMap<String, Object>();
	  params.put("messageTo", userCode);
	  List<Map<String,Object>> messages = messageDao.findMessages(params);
	  for (Map<String, Object> map : messages) {
		  Object obj = map.get("messageBody");
		  String messageBody = ClobUtil.ClobToString(obj);
		  map.put("messageBody", messageBody);
		  String packet = JSON.toJSONString(map);
		  session.getBasicRemote().sendText(packet);
	  }
	  //发送离线的消息
	  Presence presence = new Presence(Presence.Type.available);
	  OfflineMessageManager offlineMessageManager = new OfflineMessageManager(connection);
	  List<Message> offMsgs = offlineMessageManager.getMessages();
	  for (Message message : offMsgs) {
		//发送消息
		  Map<String, Object> dictMap = sendMessage(message,true);
		  //保存收到的消息
		  messageDao.addMessage(dictMap);
	  }
	  offlineMessageManager.deleteMessages();
	  connection.sendStanza(presence);//上线了
	  //添加消息接收监听,一个用户仅能配置一个
	  int clientCount = 0;
	  for (ReceiveBroker broker : clients) {
		  if (clientCount>1) {
			  break;
		  }
		  if (this.userCode.equals(broker.getUserCode())) {
			  ++clientCount;
		  }
	  }
	  if (clientCount == 1) {
		  addChatListener();
	  }
  }
  /**
   * 添加消息接收监听,一个用户仅能配置一个
   * @author wjx
   * @date 2016年11月25日
   */
  private void addChatListener(){
	  //接收消息
	  ChatManager chatManager = ChatManager.getInstanceFor(connection);
	  ChatManagerListener listener = new ChatManagerListener() {
			
		  @Override
		  public void chatCreated(Chat chat, boolean createdLocally) {
			  chat.addMessageListener(new ChatMessageListener() {
				  @Override
				  public void processMessage(Chat chat, Message message) {
					  try {
						  //发送消息
						  Map<String, Object> dictMap = sendMessage(message,false);
						  //保存收到的消息
						  messageDao.addMessage(dictMap);
					  } catch (IOException e) {
						  
					  }
				  }
			  });
		  }
	  };
	  chatManager.addChatListener(listener);
  }


/**
   * 发送消息
   * @author wjx
   * @date 2016年11月23日
   * @param message
   * @return
   * @throws IOException
   */
  private Map<String, Object> sendMessage(Message message,boolean isOffMsg) throws IOException{
	  Map<String, Object> dictMap = new HashMap<String,Object>();
	  dictMap.put("messageId", IdUtils.uuid());
	  DefaultExtensionElement element = message.getExtension("dict", "jabber:client");
	  dictMap.put("messageSubject", element.getValue("subject"));
	  dictMap.put("messageBody", message.getBody());
	  dictMap.put("messageFrom", message.getFrom().split("@")[0]);
	  dictMap.put("messageTo", userCode);
	  dictMap.put("messageType",element.getValue("type"));
	  dictMap.put("sendTime",element.getValue("sendTime"));
	  dictMap.put("readFlag", "0");
	  //推送收到的消息
	  String packet = JSON.toJSONString(dictMap);
	  if (isOffMsg) {
		  session.getBasicRemote().sendText(packet);
	  }else{
		  MessageSocket.sendUserMessage(userCode, packet);
	  }
	  
	  return dictMap;
  }
  /**
	 * @author wjx
	 * @date 2016年11月16日
	 */
	public void exit(boolean isOtherConnect) {
		if(!isOtherConnect)
			SmackUtil.disconnect(connection);
		clients.remove(this);
	}



	public String getUserCode() {
		return userCode;
	}


	
  
}