package com.zoe.optimus.service.message.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;
import java.sql.Clob;
import java.sql.SQLException;

import oracle.sql.CLOB;

/**
 * <p>标题：</p>
 * <p>描述：</p>
 * <p>版权：Copyright (c) 2016</p>
 * <p>公司：智业股份有限公司</p>
 *
 * @version 1.0
 * @author wjx
 * @createDate 2016年11月18日
 */
public class ClobUtil {

	/**
	 * CLOB转String
	 * @author wjx
	 * @date 2016年11月21日
	 * @param obj
	 * @return
	 * @throws SQLException
	 * @throws IOException
	 */
	public static String ClobToString(Object obj) throws SQLException, IOException {

		String reString = "";
		StringBuffer sb = new StringBuffer();
		if (obj instanceof CLOB) {
			CLOB clob = (CLOB) obj;
			Reader is = clob.getCharacterStream();// 得到流
			BufferedReader br = new BufferedReader(is);
			String s = br.readLine();
			while (s != null) {// 执行循环将字符串全部取出付值给StringBuffer由StringBuffer转成STRING
				sb.append(s);
				s = br.readLine();
			}
		} else if (obj instanceof Clob) {
			Clob clob = (Clob) obj;
			Reader is = clob.getCharacterStream();// 得到流
			BufferedReader br = new BufferedReader(is);
			String s = br.readLine();
			while (s != null) {// 执行循环将字符串全部取出付值给StringBuffer由StringBuffer转成STRING
				sb.append(s);
				s = br.readLine();
			}
		} else if (obj instanceof com.mysql.jdbc.Clob) {
			com.mysql.jdbc.Clob clob = (com.mysql.jdbc.Clob) obj;
			Reader is = clob.getCharacterStream();// 得到流
			BufferedReader br = new BufferedReader(is);
			String s = br.readLine();
			while (s != null) {// 执行循环将字符串全部取出付值给StringBuffer由StringBuffer转成STRING
				sb.append(s);
				s = br.readLine();
			}
		} else {
			sb.append(obj.toString());
		}
		
		reString = sb.toString();
		return reString;
	}
}
