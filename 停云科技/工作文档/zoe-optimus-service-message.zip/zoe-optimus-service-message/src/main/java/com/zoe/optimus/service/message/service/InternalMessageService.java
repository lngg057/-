package com.zoe.optimus.service.message.service;

import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.springframework.stereotype.Service;

import com.zoe.optimus.service.message.dao.MessageDao;
import com.zoe.optimus.service.message.util.SpringContextHolder;

/**
 * <p>标题：</p>
 * <p>描述：</p>
 * <p>版权：Copyright (c) 2016</p>
 * <p>公司：智业股份有限公司</p>
 *
 * @version 1.0
 * @author wjx
 * @createDate 2016年11月7日
 */
@Service("internalMessageService")
public class InternalMessageService {

	//线程
	private static ExecutorService pool = Executors.newCachedThreadPool();
	
	private MessageDao messageDao = (MessageDao) SpringContextHolder.getBean("messageDao");
	
	/**
	   * 注册消息代理
	   *
	   * @param broker 消息代理
	   */
	 public void connect(ReceiveBroker broker) {
	    pool.submit(broker);
	 }


	/**
	 * 读取消息变更状态
	 * @author wjx
	 * @date 2016年11月18日
	 * @param map
	 */
	public void readMessage(Map<String, Object> map){
		messageDao.updateReadFlag(map);
	}


}
