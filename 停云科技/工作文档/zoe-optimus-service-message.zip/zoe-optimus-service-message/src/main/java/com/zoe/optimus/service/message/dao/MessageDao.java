package com.zoe.optimus.service.message.dao;

import java.util.List;
import java.util.Map;

import com.zoe.optimus.service.message.annotation.MyBatisDao;

/**
 * <p>标题：消息dao层操作</p>
 * <p>描述：</p>
 * <p>版权：Copyright (c) 2016</p>
 * <p>公司：智业股份有限公司</p>
 *
 * @version 1.0
 * @author wjx
 * @createDate 2016年11月17日
 */
@MyBatisDao
public interface MessageDao {
	
	int addMessage(Map<String,Object> dictMap);
	
	
	List<Map<String,Object>> findMessages(Map<String,Object> params);

	/**
	 * @author wjx
	 * @date 2016年11月18日
	 * @param map
	 */
	void updateReadFlag(Map<String, Object> map);
	

}
