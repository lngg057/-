package com.zoe.optimus.service.message.entity;

import org.apache.commons.lang3.StringUtils;

/**
 * <p>标题: 接口返回实体</p>
 * <p>描述: </p>
 * <p>版权: Copyright (c) 2016</p>
 * <p>公司: 智业软件股份有限公司</p>
 *
 * @version: 1.0
 * @author: cxy
 * @date 2016/9/8
 */
public class ResultModel {
    // 成功编码
    public static final String SUCCESS_CODE = "00000";
    // 异常编码
    public static final String ERROR_CODE = "00001";

    private String code = SUCCESS_CODE;//响应编码
    private Object data;//响应数据
    private String message;//响应信息
    private String error;//异常详细信息

    public ResultModel() {
    }

    public ResultModel(String code, Object data, String message, String error) {
        this.code = code;
        this.data = data;
        this.message = message;
        this.error = error;
    }

    /**
     * 成功时，返回实体的静态构造方法
     * 不进行国际化翻译，原样输出
     * @param message 响应消息
     * @param data    数据
     * @return ResultModel
     */
    public static ResultModel success(String message, Object data) {
        return new ResultModel(SUCCESS_CODE, data, message, "");

    }


    /**
     * 失败时，返回实体的静态构造方法
     * 不进行国际化翻译，原样输出
     * @param code    响应码
     * @param message 响应消息
     * @return ResultModel
     */
    public static ResultModel fail(String code, String message, String error) {
        return new ResultModel(code, null, message, error);
    }


    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public Object getData() {
        if (null == data || "null".equals(data)) {
            return "";
        }
        return data;
    }

    public void setData(Object data) {
        this.data = data;
    }

    public String getMessage() {
        if (StringUtils.isEmpty(message)) {
            return "";
        }
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getError() {
        return error;
    }

    public void setError(String error) {
        this.error = error;
    }
}
