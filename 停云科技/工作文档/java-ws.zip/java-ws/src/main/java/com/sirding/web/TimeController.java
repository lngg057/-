package com.sirding.web;

import org.apache.log4j.Logger;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.stereotype.Controller;

import com.sirding.domain.SimpleJson;
import com.sirding.util.DateUtil;
/**
 * @Described			: 
 * @project				: com.sirding.web.RandomController
 * @author 				: zc.ding
 * @date 				: 2016年12月3日
 */
@Controller
public class TimeController {
	private final Logger logger = Logger.getLogger(getClass());

	@MessageMapping("/time")
	@SendTo(value = "/topic/getTime")
	public SimpleJson getRandom(SimpleJson simpleJson){
		logger.debug("接收到客户端的数据信息：" + simpleJson.getName());
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		SimpleJson json = new SimpleJson("time", new SimpleJson("time", DateUtil.getNow()));
		return json;
	}
}
