package com.sirding.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.core.MessageSendingOperations;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.sirding.domain.SimpleJson;
import com.sirding.util.DateUtil;

@Service
public class  AutoPub{

	@Autowired
	private MessageSendingOperations<String> messagingTemplate;
	
	@Scheduled(fixedDelay=10000)
	public void sendQuotes() {
		System.out.println("广播消息");
		this.messagingTemplate.convertAndSend("/topic/getTime", new SimpleJson("time", DateUtil.getNow()));
	}
}
