package com.tingyun.messageReceipt;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.commons.lang.StringUtils;
import org.eclipse.jetty.util.ajax.JSON;
import org.jivesoftware.openfire.OfflineMessageStore;
import org.jivesoftware.openfire.SessionManager;
import org.jivesoftware.openfire.container.Plugin;
import org.jivesoftware.openfire.container.PluginManager;
import org.jivesoftware.openfire.interceptor.InterceptorManager;
import org.jivesoftware.openfire.interceptor.PacketInterceptor;
import org.jivesoftware.openfire.interceptor.PacketRejectedException;
import org.jivesoftware.openfire.session.ClientSession;
import org.jivesoftware.openfire.session.Session;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.xmpp.packet.Message;
import org.xmpp.packet.Packet;

/**
 * 消息回执插件
 */
public class TestMessageReceiptPlugin implements Plugin, PacketInterceptor {

    private static final Logger log                 = LoggerFactory.getLogger(TestMessageReceiptPlugin.class);
    private static final String USER_SOURCE_FARTNER = "0";

    private InterceptorManager  interceptoerManager;
    private SessionManager      sessionManager;
    private UserInfoDao         userInfoDao;

    public TestMessageReceiptPlugin() {
        interceptoerManager = InterceptorManager.getInstance();
        userInfoDao = new UserInfoDao();
    }

    @Override
    //初始化插件
    public void initializePlugin(PluginManager manager, File pluginDirectory) {
        interceptoerManager.addInterceptor(this);
        sessionManager = SessionManager.getInstance();
        System.out.println("......加载消息回复插件成功！");
    }

    @Override
    //服务器断开时销毁插件
    public void destroyPlugin() {
        interceptoerManager.removeInterceptor(this);
        System.out.println("......销毁消息回复插件成功！");
    }

    @Override
    //消息拦截器
    public void interceptPacket(Packet packet, Session session, boolean incoming,
                                boolean processed) throws PacketRejectedException {
        log.debug("-----------------接收到的消息内容：" + packet.toXML());
        Packet copyPacket = packet.createCopy();

        if (packet instanceof Message) {
            log.debug("当前packet类型为Message");
            Message message = (Message) copyPacket;

            // 一对一聊天，单人模式，判断所拦截消息的类型为chat
            if (message.getType() == Message.Type.chat) {
                log.debug("当前Message类型为chat");

                // 程序执行中；是否为结束或返回状态（是否是当前session用户发送消息）
                if (processed || !incoming) {
                    return;
                }
                // 判断接受者是否在线，2代表离线状态，1代表在线状态，0代表用戶不存在
                if (IsOnLineUtils.IsUserOnLine(message.getTo()) == 2) {
                    // 离线時，向offline表写数据
                    OfflineMessageStore offlineMessageStore = new OfflineMessageStore();
                    offlineMessageStore.addMessage(message);

                    // 获取接收方回执信息，并向客户端发回执
                    UserInfo userinfo = userInfoDao.getUserByUserName(message.getTo().getNode());
                    String content = userinfo.getAutoReply();
                    String source = userinfo.getSource();
                    
                    log.debug("--------------" + message.getTo().getNode() +"------------content:" + content + " source:" + source);

                    //当原始接收方为商家不在线的时候进行系统消息发送
                    if (USER_SOURCE_FARTNER.equalsIgnoreCase(source)) {
                        if (StringUtils.isEmpty(content)) {
                            content = "The shop " + message.getTo().getNode() + " now is offline!";
                        }
                        //拼接成json串传入信息体中
                        Map<String, Object> map = new ConcurrentHashMap<String, Object>();
                        map.put("text", content);
                        map.put("type", 0);
                        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                        map.put("time", sdf.format(new Date()));
                        ClientSession session2 = this.sessionManager.getSession(message.getFrom());
                        Message receiptMessage = new Message();
                        receiptMessage.setID(message.getID());
                        receiptMessage.setTo(session2.getAddress());
                        receiptMessage.setFrom(message.getTo());
                        receiptMessage.setType(message.getType());
                        receiptMessage.setThread(message.getThread());
                        receiptMessage.setBody(JSON.toString(map));
                        try {
                            //XMPPServer.getInstance().getPacketDeliverer().deliver(receiptMessage);
                            session2.process(receiptMessage);
                            log.debug("服务端回执成功！Message:" + receiptMessage.toString());
                        } catch (Exception e) {
                            log.debug("服务端回执失败！", e);
                        }
                    }
                }
            }
        }
    }
}
