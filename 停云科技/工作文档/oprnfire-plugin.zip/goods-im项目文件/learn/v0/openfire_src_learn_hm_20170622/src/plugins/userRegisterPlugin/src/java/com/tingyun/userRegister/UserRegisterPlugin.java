/**
 * tingyun.tech Inc.
 */
package com.tingyun.userRegister;

import java.io.File;

import org.jivesoftware.openfire.XMPPServer;
import org.jivesoftware.openfire.container.Plugin;
import org.jivesoftware.openfire.container.PluginManager;

/**
 * <pre>
 * 
 * </pre>
 *
 * @author Everett 
 * @version UserRegisterPlugin.java, v 0.1 2017年7月17日 下午12:09:55 Everett Exp
 */
public class UserRegisterPlugin implements Plugin {

    private XMPPServer    server;
    UserInfoIQHander      userInfoIQHander = null;

    /** 
     * <pre>
     * 拦截包含jabber:iq:register查询的特定请求，如下：
     * 例：
     * {@code
     * <iq id="g0G4m-1" to="server" type="set">
     *     <query xmlns="jabber:iq:register">
     *         <username>username</username>
     *         <email>username@test.com</email>
     *         <name>username</name>
     *         <password>1</password>
     *         <source>1</source>
     *     </query>
     * </iq>
     * }
     * </pre>
     * 
     * @param manager
     * @param pluginDirectory
     * @see org.jivesoftware.openfire.container.Plugin#initializePlugin(org.jivesoftware.openfire.container.PluginManager, java.io.File)
     */
    @Override
    public void initializePlugin(PluginManager manager, File pluginDirectory) {
        server = XMPPServer.getInstance();
        /*注册用户注册请求拦截器*/
        userInfoIQHander = new UserInfoIQHander("UserInfoIQHander");
        server.getIQRouter().addHandler(userInfoIQHander);

        System.out.println("......开启用户注册插件成功！");
    }

    /** 
     * 
     * @see org.jivesoftware.openfire.container.Plugin#destroyPlugin()
     */
    @Override
    public void destroyPlugin() {
        /*移除注册用户信息拦截器 */
        if (userInfoIQHander != null) {
            server.getIQRouter().removeHandler(userInfoIQHander);
            userInfoIQHander = null;
        }

        System.out.println("......销毁用户注册插件成功！");
    }

}
