/**
 * tingyun.tech Inc.
 */
package com.tingyun.messageReceipt;

import java.util.Date;

/**
 * <pre>
 * 
 * </pre>
 *
 * @author Everett 
 * @version UserInfo.java, v 0.1 2017年7月17日 下午6:31:21 Everett Exp
 */
public class UserInfo {
    private String username;
    private String name;
    private String email;
    private String source;
    private String autoReply;
    private Date   creationDate;
    private Date   modificationDate;

    /**
     * Getter method for property <tt>username</tt>.
     * 
     * @return property value of username
     */
    public String getUsername() {
        return username;
    }

    /**
     * Setter method for property <tt>username</tt>.
     * 
     * @param username value to be assigned to property username
     */
    public void setUsername(String username) {
        this.username = username;
    }

    /**
     * Getter method for property <tt>name</tt>.
     * 
     * @return property value of name
     */
    public String getName() {
        return name;
    }

    /**
     * Setter method for property <tt>name</tt>.
     * 
     * @param name value to be assigned to property name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Getter method for property <tt>email</tt>.
     * 
     * @return property value of email
     */
    public String getEmail() {
        return email;
    }

    /**
     * Setter method for property <tt>email</tt>.
     * 
     * @param email value to be assigned to property email
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * Getter method for property <tt>source</tt>.
     * 
     * @return property value of source
     */
    public String getSource() {
        return source;
    }

    /**
     * Setter method for property <tt>source</tt>.
     * 
     * @param source value to be assigned to property source
     */
    public void setSource(String source) {
        this.source = source;
    }

    /**
     * Getter method for property <tt>autoReply</tt>.
     * 
     * @return property value of autoReply
     */
    public String getAutoReply() {
        return autoReply;
    }

    /**
     * Setter method for property <tt>autoReply</tt>.
     * 
     * @param autoReply value to be assigned to property autoReply
     */
    public void setAutoReply(String autoReply) {
        this.autoReply = autoReply;
    }

    /**
     * Getter method for property <tt>creationDate</tt>.
     * 
     * @return property value of creationDate
     */
    public Date getCreationDate() {
        return creationDate;
    }

    /**
     * Setter method for property <tt>creationDate</tt>.
     * 
     * @param creationDate value to be assigned to property creationDate
     */
    public void setCreationDate(Date creationDate) {
        this.creationDate = creationDate;
    }

    /**
     * Getter method for property <tt>modificationDate</tt>.
     * 
     * @return property value of modificationDate
     */
    public Date getModificationDate() {
        return modificationDate;
    }

    /**
     * Setter method for property <tt>modificationDate</tt>.
     * 
     * @param modificationDate value to be assigned to property modificationDate
     */
    public void setModificationDate(Date modificationDate) {
        this.modificationDate = modificationDate;
    }

}
