package com.tingyun.messageReceipt;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URLConnection;

import org.xmpp.packet.JID;

public class IsOnLineUtils {
    /**
     * 判断openfire用户的状态 strUrl : url格式 -
     * http://my.openfire.com:9090/plugins/presence/status?jid=user1@my.openfire
     * .com&type=xml 返回值 : 0 - 用户不存在; 1 - 用户在线; 2 - 用户离线 说明 ：必须要求 openfire加载
     * presence 插件，同时设置任何人都可以访问
     */
    public final static String URL = "http://47.90.104.235:9092/plugins/presence/status?jid=";

    public static short IsUserOnLine(JID jid) {
        String strUrl = URL + jid + "&type=xml";
        System.out.println("查询用户是否在线的url： "+strUrl);
        short shOnLineState = 0; // -不存在-
        try {
            java.net.URL oUrl = new  java.net.URL(strUrl);
            URLConnection oConn = oUrl.openConnection();
            if (oConn != null) {
                BufferedReader oIn = new BufferedReader(new InputStreamReader(oConn.getInputStream()));
                if (null != oIn) {
                    String strFlag = oIn.readLine();
                    oIn.close();
                    if (strFlag.indexOf("type=\"unavailable\"") >= 0) {
                        shOnLineState = 2;
                    }
                    if (strFlag.indexOf("type=\"error\"") >= 0) {
                        shOnLineState = 0;
                    } else if (strFlag.indexOf("priority") >= 0 || strFlag.indexOf("id=\"") >= 0) {
                        shOnLineState = 1;
                    }
                }
            }
        } catch (Exception e) {
        }
        System.out.println("查询用户是否在线的结果(0 - 用户不存在; 1 - 用户在线; 2 - 用户离线)： "+shOnLineState);
        return shOnLineState;
    }
}