/**
 * tingyun.tech Inc.
 */
package com.tingyun.messageReceipt;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.jivesoftware.database.DbConnectionManager;
import org.jivesoftware.openfire.auth.AuthFactory;
import org.jivesoftware.openfire.user.DefaultUserProvider;
import org.jivesoftware.openfire.user.UserNotFoundException;
import org.jivesoftware.util.JiveGlobals;
import org.jivesoftware.util.LocaleUtils;
import org.jivesoftware.util.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * <pre>
 * 
 * </pre>
 *
 * @author Everett 
 * @version UserInfoDao.java, v 0.1 2017年7月17日 下午12:14:30 Everett Exp
 */
public class UserInfoDao {

    private static final Logger Log                  = LoggerFactory.getLogger(DefaultUserProvider.class);
    private static final String GET_USER_BY_USERNAME = "SELECT username,name,email,creationDate,modificationDate,source,autoReply FROM ofUser WHERE username=?";
    private static final String INSERT_USER          = "INSERT INTO ofUser (username,plainPassword,encryptedPassword,name,email,creationDate,modificationDate,source) "
                                                       + "VALUES (?,?,?,?,?,?,?,?)";

    /**
     * <pre>
     * 
     * </pre>
     *
     * @param userName
     * @return
     */
    public UserInfo getUserByUserName(String userName) {
        Connection con = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        List<UserInfo> list = new ArrayList<UserInfo>();

        try {
            con = DbConnectionManager.getConnection();
            pstmt = con.prepareStatement(GET_USER_BY_USERNAME);
            pstmt.setString(1, userName);
            rs = pstmt.executeQuery();
            if (rs.wasNull()) {
                throw new UserNotFoundException();
            }
            while(rs.next()){ 
                UserInfo userInfo = new UserInfo();
                userInfo.setUsername(rs.getString(1));
                userInfo.setName(rs.getString(2));
                userInfo.setEmail(rs.getString(3));
                userInfo.setCreationDate(rs.getDate(4));
                userInfo.setModificationDate(rs.getDate(5));
                userInfo.setSource(rs.getString(6));
                userInfo.setAutoReply(rs.getString(7));
                
                list.add(userInfo);
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            DbConnectionManager.closeConnection(rs, pstmt, con);
        }
        return list.get(0);
    }

    /**
     * <pre>
     * 创建ofuser
     * </pre>
     *
     * @param username 用户名
     * @param password 密码
     * @param name 昵称
     * @param email 邮箱
     * @param source 用户来源
     */
    public void createUser(String username, String password, String name, String email, String source) {
        // Determine if the password should be stored as plain text or encrypted.
        boolean usePlainPassword = JiveGlobals.getBooleanProperty("user.usePlainPassword");
        String encryptedPassword = null;
        if (!usePlainPassword) {
            try {
                encryptedPassword = AuthFactory.encryptPassword(password);
                // Set password to null so that it's inserted that way.
                password = null;
            } catch (UnsupportedOperationException uoe) {
                // Encrypting the password may have failed if in setup mode. Therefore,
                // use the plain password.
            }
        }

        Date now = new Date();
        Connection con = null;
        PreparedStatement pstmt = null;
        try {
            con = DbConnectionManager.getConnection();
            pstmt = con.prepareStatement(INSERT_USER);
            pstmt.setString(1, username);
            if (password == null) {
                pstmt.setNull(2, Types.VARCHAR);
            } else {
                pstmt.setString(2, password);
            }

            if (encryptedPassword == null) {
                pstmt.setNull(3, Types.VARCHAR);
            } else {
                pstmt.setString(3, encryptedPassword);
            }

            if (name == null || name.matches("\\s*")) {
                pstmt.setNull(4, Types.VARCHAR);
            } else {
                pstmt.setString(4, name);
            }

            if (email == null || email.matches("\\s*")) {
                pstmt.setNull(5, Types.VARCHAR);
            } else {
                pstmt.setString(5, email);
            }

            pstmt.setString(6, StringUtils.dateToMillis(now));

            pstmt.setString(7, StringUtils.dateToMillis(now));

            if (source == null) {
                pstmt.setNull(8, Types.VARCHAR);
            } else {
                pstmt.setString(8, source);
            }

            pstmt.execute();
        } catch (Exception e) {
            Log.error(LocaleUtils.getLocalizedString("admin.error"), e);
        } finally {
            DbConnectionManager.closeConnection(pstmt, con);
        }
        return;
    }
}
