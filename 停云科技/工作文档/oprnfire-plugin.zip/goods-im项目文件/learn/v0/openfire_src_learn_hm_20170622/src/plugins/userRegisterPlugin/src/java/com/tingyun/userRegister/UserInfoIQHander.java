/**
 * tingyun.tech Inc.
 */
package com.tingyun.userRegister;

import java.util.Iterator;
import java.util.List;

import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.QName;
import org.jivesoftware.openfire.IQHandlerInfo;
import org.jivesoftware.openfire.XMPPServer;
import org.jivesoftware.openfire.auth.UnauthorizedException;
import org.jivesoftware.openfire.handler.IQHandler;
import org.jivesoftware.openfire.session.ClientSession;
import org.jivesoftware.openfire.session.Session;
import org.jivesoftware.openfire.user.User;
import org.jivesoftware.openfire.user.UserManager;
import org.jivesoftware.openfire.user.UserNotFoundException;
import org.jivesoftware.util.JiveGlobals;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.xmpp.forms.DataForm;
import org.xmpp.forms.FormField;
import org.xmpp.packet.IQ;
import org.xmpp.packet.JID;
import org.xmpp.packet.PacketError;

import gnu.inet.encoding.Stringprep;

/**
 * <pre>
 * 继承IQHandler，模拟IQRegisterHandler实现，用于用户信息注册扩展使用
 * </pre>
 *
 * @author Everett 
 * @version UserInfoIQHander.java, v 0.1 2017年7月17日 下午12:11:20 Everett Exp
 * @see org.jivesoftware.openfire.handler.IQRegisterHandler
 */
public class UserInfoIQHander extends IQHandler {

    private static final Logger Log = LoggerFactory.getLogger(UserInfoIQHander.class);

    private IQHandlerInfo       info;
    private UserInfoDao         userInfoDao;
    private UserManager         userManager;

    private static boolean      registrationEnabled;
    private static boolean      canChangePassword;
    private static Element      probeResult;

    /**
     * @param moduleName
     */
    public UserInfoIQHander(String moduleName) {
        super(moduleName);
        // TODO Auto-generated constructor stub
        //初始化用户注册请求,过滤jabber:iq:register请求
        info = new IQHandlerInfo("query", "jabber:iq:register");
    }

    /** 
     * @param server
     * @see org.jivesoftware.openfire.handler.IQHandler#initialize(org.jivesoftware.openfire.XMPPServer)
     */
    @Override
    public void initialize(XMPPServer server) {
        super.initialize(server);
        userManager = server.getUserManager();

        if (probeResult == null) {
            // Create the basic element of the probeResult which contains the basic registration
            // information (e.g. username, passoword and email)
            probeResult = DocumentHelper.createElement(QName.get("query", "jabber:iq:register"));
            probeResult.addElement("username");
            probeResult.addElement("password");
            probeResult.addElement("email");
            probeResult.addElement("name");

            // Create the registration form to include in the probeResult. The form will include
            // the basic information plus name and visibility of name and email.
            // TODO Future versions could allow plugin modules to add new fields to the form 
            final DataForm registrationForm = new DataForm(DataForm.Type.form);
            registrationForm.setTitle("XMPP Client Registration");
            registrationForm.addInstruction("Please provide the following information");

            final FormField fieldForm = registrationForm.addField();
            fieldForm.setVariable("FORM_TYPE");
            fieldForm.setType(FormField.Type.hidden);
            fieldForm.addValue("jabber:iq:register");

            final FormField fieldUser = registrationForm.addField();
            fieldUser.setVariable("username");
            fieldUser.setType(FormField.Type.text_single);
            fieldUser.setLabel("Username");
            fieldUser.setRequired(true);

            final FormField fieldName = registrationForm.addField();
            fieldName.setVariable("name");
            fieldName.setType(FormField.Type.text_single);
            fieldName.setLabel("Full name");
            if (UserManager.getUserProvider().isNameRequired()) {
                fieldName.setRequired(true);
            }

            final FormField fieldMail = registrationForm.addField();
            fieldMail.setVariable("email");
            fieldMail.setType(FormField.Type.text_single);
            fieldMail.setLabel("Email");
            if (UserManager.getUserProvider().isEmailRequired()) {
                fieldMail.setRequired(true);
            }

            final FormField fieldPwd = registrationForm.addField();
            fieldPwd.setVariable("password");
            fieldPwd.setType(FormField.Type.text_private);
            fieldPwd.setLabel("Password");
            fieldPwd.setRequired(true);

            final FormField fieldSource = registrationForm.addField();
            fieldSource.setVariable("source");
            fieldSource.setType(FormField.Type.text_single);
            fieldSource.setLabel("Source");
            fieldSource.setRequired(true);

            // Add the registration form to the probe result.
            probeResult.add(registrationForm.getElement());
        }
        // See if in-band registration should be enabled (default is true).
        registrationEnabled = JiveGlobals.getBooleanProperty("register.inband", true);
        // See if users can change their passwords (default is true).
        canChangePassword = JiveGlobals.getBooleanProperty("register.password", true);
    }

    /** 
     * @param packet
     * @return
     * @throws UnauthorizedException
     * @see org.jivesoftware.openfire.handler.IQHandler#handleIQ(org.xmpp.packet.IQ)
     */
    @Override
    public IQ handleIQ(IQ packet) throws UnauthorizedException {
        System.out.println("进入handleIQ方法");
        ClientSession session = sessionManager.getSession(packet.getFrom());

        IQ reply = null;

        if (session == null) {
            Log.error("Error during registration. Session not found in " + sessionManager.getPreAuthenticatedKeys()
                      + " for key " + packet.getFrom());
            // This error packet will probably won't make it through
            reply = IQ.createResultIQ(packet);
            reply.setChildElement(packet.getChildElement().createCopy());
            reply.setError(PacketError.Condition.internal_server_error);
            return reply;
        }

        try {
            userInfoDao = new UserInfoDao();
            Element childElement = packet.getChildElement();
            String namespace = childElement.getNamespaceURI();
            System.out.println("namespace:" + namespace);

            if (IQ.Type.get.equals(packet.getType())) {

                // If inband registration is not allowed, return an error.
                if (!registrationEnabled) {
                    reply = IQ.createResultIQ(packet);
                    reply.setChildElement(packet.getChildElement().createCopy());
                    reply.setError(PacketError.Condition.forbidden);
                } else {
                    reply = IQ.createResultIQ(packet);
                    if (session.getStatus() == Session.STATUS_AUTHENTICATED) {
                        try {
                            UserInfo user = userInfoDao.getUserByUserName(session.getUsername());
                            Element currentRegistration = probeResult.createCopy();
                            currentRegistration.addElement("registered");
                            currentRegistration.element("username").setText(user.getUsername());
                            currentRegistration.element("password").setText("");
                            currentRegistration.element("email")
                                .setText(user.getEmail() == null ? "" : user.getEmail());
                            currentRegistration.element("name").setText(user.getName());
                            currentRegistration.element("source").setText(user.getSource());

                            Element form = currentRegistration.element(QName.get("x", "jabber:x:data"));
                            Iterator fields = form.elementIterator("field");
                            Element field;
                            while (fields.hasNext()) {
                                field = (Element) fields.next();
                                if ("username".equals(field.attributeValue("var"))) {
                                    field.addElement("value").addText(user.getUsername());
                                } else if ("name".equals(field.attributeValue("var"))) {
                                    field.addElement("value").addText(user.getName());
                                } else if ("email".equals(field.attributeValue("var"))) {
                                    field.addElement("value").addText(user.getEmail() == null ? "" : user.getEmail());
                                } else if ("source".equals(field.attributeValue("var"))) {
                                    field.addElement("value").addText(user.getSource());
                                }
                            }
                            reply.setChildElement(currentRegistration);
                        } catch (UserNotFoundException e) {
                            reply.setChildElement(probeResult.createCopy());
                        }
                    } else {
                        // This is a workaround. Since we don't want to have an incorrect TO attribute
                        // value we need to clean up the TO attribute. The TO attribute will contain an
                        // incorrect value since we are setting a fake JID until the user actually
                        // authenticates with the server.
                        reply.setTo((JID) null);
                        reply.setChildElement(probeResult.createCopy());
                    }
                }

            } else if (IQ.Type.set.equals(packet.getType())) {

                Element iqElement = packet.getChildElement();
                if (iqElement.element("remove") != null) {

                } else {
                    Log.error("进入用户注册生成账号流程");
                    String username;
                    String password = null;
                    String email = null;
                    String name = null;
                    String source = null;
                    DataForm registrationForm;
                    FormField field;

                    Element formElement = iqElement.element("x");
                    // Check if a form was used to provide the registration info
                    if (formElement != null) {
                        // Get the sent form
                        registrationForm = new DataForm(formElement);
                        // Get the username sent in the form
                        List<String> values = registrationForm.getField("username").getValues();
                        username = (!values.isEmpty() ? values.get(0) : " ");
                        // Get the password sent in the form
                        field = registrationForm.getField("password");
                        if (field != null) {
                            values = field.getValues();
                            password = (!values.isEmpty() ? values.get(0) : " ");
                        }
                        // Get the email sent in the form
                        field = registrationForm.getField("email");
                        if (field != null) {
                            values = field.getValues();
                            email = (!values.isEmpty() ? values.get(0) : " ");
                        }
                        // Get the name sent in the form
                        field = registrationForm.getField("name");
                        if (field != null) {
                            values = field.getValues();
                            name = (!values.isEmpty() ? values.get(0) : " ");
                        }

                        // Get the source sent in the form
                        field = registrationForm.getField("source");
                        if (field != null) {
                            values = field.getValues();
                            source = (!values.isEmpty() ? values.get(0) : " ");
                        }
                    } else {
                        // Get the registration info from the query elements
                        username = iqElement.elementText("username");
                        password = iqElement.elementText("password");
                        email = iqElement.elementText("email");
                        name = iqElement.elementText("name");
                        source = iqElement.elementText("source");
                    }

                    if (email != null && email.matches("\\s*")) {
                        email = null;
                    }
                    if (name != null && name.matches("\\s*")) {
                        name = null;
                    }

                    // So that we can set a more informative error message back, lets test this for
                    // stringprep validity now.
                    if (username != null) {
                        Stringprep.nodeprep(username);
                    }

                    if (session.getStatus() == Session.STATUS_AUTHENTICATED) {
                        // Flag that indicates if the user is *only* changing his password
                        boolean onlyPassword = false;
                        if (iqElement.elements().size() == 2 && iqElement.element("username") != null
                            && iqElement.element("password") != null) {
                            onlyPassword = true;
                        }
                        // If users are not allowed to change their password, return an error.
                        if (password != null && !canChangePassword) {
                            reply = IQ.createResultIQ(packet);
                            reply.setChildElement(packet.getChildElement().createCopy());
                            reply.setError(PacketError.Condition.forbidden);
                            return reply;
                        }
                        // If inband registration is not allowed, return an error.
                        else if (!onlyPassword && !registrationEnabled) {
                            reply = IQ.createResultIQ(packet);
                            reply.setChildElement(packet.getChildElement().createCopy());
                            reply.setError(PacketError.Condition.forbidden);
                            return reply;
                        } else {
                            User user = userManager.getUser(session.getUsername());

                            if ((password != null && password.trim().length() > 0)
                                && (!user.getUsername().equalsIgnoreCase(username))) {
                                // An admin can create new accounts when logged in.
                                userInfoDao.createUser(username, password, name, email, source);
                            } else {
                                // Deny registration of users with no password
                                //拒绝已有用户注册
                                reply = IQ.createResultIQ(packet);
                                reply.setChildElement(packet.getChildElement().createCopy());
                                reply.setError(PacketError.Condition.not_acceptable);
                                return reply;
                            }
                        }
                    } else {
                        // If inband registration is not allowed, return an error.
                        if (!registrationEnabled) {
                            reply = IQ.createResultIQ(packet);
                            reply.setChildElement(packet.getChildElement().createCopy());
                            reply.setError(PacketError.Condition.forbidden);
                            return reply;
                        }
                        // Inform the entity of failed registration if some required
                        // information was not provided
                        else if (password == null || password.trim().length() == 0) {
                            reply = IQ.createResultIQ(packet);
                            reply.setChildElement(packet.getChildElement().createCopy());
                            reply.setError(PacketError.Condition.not_acceptable);
                            return reply;
                        } else {
                            // Create the new account
                            userInfoDao.createUser(username, password, name, email, source);
                        }
                    }
                    reply = IQ.createResultIQ(packet);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        if (reply != null) {
            // why is this done here instead of letting the iq handler do it?
            // ↑我也不知道为啥，这里可能是直接通过session将拼接的回话返回了，而不需要通过deliver进行分发?
            session.process(reply);
        }
        return null;
    }

    /** 
     * @return
     * @see org.jivesoftware.openfire.handler.IQHandler#getInfo()
     */
    @Override
    public IQHandlerInfo getInfo() {
        return info;
    }
}
